﻿namespace Todo.Api.Models
{
    public class Category
    {
        public int Id { get; set; } // Primærnøkkel
        public string Name { get; set; } = string.Empty; // Kategoriens navn

        // En kategori kan ha flere TodoItems
        public ICollection<TodoItem> Todos { get; set; } = new List<TodoItem>();
    }
}
