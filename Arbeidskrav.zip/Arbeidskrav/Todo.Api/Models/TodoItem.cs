﻿using System.ComponentModel.DataAnnotations;

namespace Todo.Api.Models
{
    public class TodoItem
    {
        public int Id { get; set; } // Primærnøkkel

        [Required]
        [StringLength(100, ErrorMessage = "Tittelen kan ha maks 100 tegn.")]
        public string Title { get; set; } = string.Empty; // Tittel på TodoItem

        [StringLength(500, ErrorMessage = "Beskrivelsen kan være på maks 500 tegn.")]
        public string? Description { get; set; } // Beskrivelse av TodoItem

        public bool IsCompleted { get; set; } = false; // Status på TodoItem (Fullført/Ikke fullført)

        // Fremmednøkkel til Category
        public int? CategoryId { get; set; }
        public Category? Category { get; set; } // Relasjon til Category
    }
}
