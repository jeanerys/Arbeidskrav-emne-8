﻿using Todo.Api.Models;

public interface ITodoRepository
{
    Task<IEnumerable<TodoItem>> GetAllAsync();
    Task<TodoItem?> GetByIdAsync(int id);
    Task<IEnumerable<TodoItem>> GetByCategoryAsync(int categoryId);
    Task<IEnumerable<TodoItem>> GetCompletedAsync();
    Task<int> GetCountByCategoryAsync(int categoryId);
    Task AddAsync(TodoItem todo);
    Task UpdateAsync(TodoItem todo);
    Task DeleteAsync(int id);
    Task SaveChangesAsync();
}