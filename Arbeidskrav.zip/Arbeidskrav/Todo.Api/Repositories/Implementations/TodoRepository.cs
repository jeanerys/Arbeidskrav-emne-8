﻿using Todo.Api.Data;
using Todo.Api.Models;
using Microsoft.EntityFrameworkCore;

public class TodoRepository : ITodoRepository
{
    private readonly TodoItemContext _context;

    public TodoRepository(TodoItemContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<TodoItem>> GetAllAsync() =>
        await _context.TodoItems
            .Include(t => t.Category)
            .ToListAsync();

    public async Task<TodoItem?> GetByIdAsync(int id) => 
        await _context.TodoItems
            .Include(t => t.Category)
            .FirstOrDefaultAsync(t => t.Id == id);

    public async Task<IEnumerable<TodoItem>> GetByCategoryAsync(int categoryId) => 
        await _context.TodoItems
            .Where(t => t.CategoryId == categoryId)
            .Include(t => t.Category)
            .ToListAsync();

    public async Task<int> GetCountByCategoryAsync(int categoryId) =>
        await _context.TodoItems
            .Where(t => t.CategoryId == categoryId)
            .CountAsync();

    public async Task<IEnumerable<TodoItem>> GetCompletedAsync() =>
        await _context.TodoItems
            .Where(t => t.IsCompleted)
            .Include(t => t.Category)
            .ToListAsync();

    public async Task AddAsync(TodoItem todo) => 
        await _context.TodoItems.AddAsync(todo);

    public Task UpdateAsync(TodoItem todo) 
    {
        _context.TodoItems.Update(todo); 
        return Task.CompletedTask;
    }

    public async Task DeleteAsync(int id) 
    {
        var todo = await _context.TodoItems.FirstOrDefaultAsync(t => t.Id == id);
        if (todo != null)
        {
            _context.TodoItems.Remove(todo);
        }
    }

    public async Task SaveChangesAsync() => 
        await _context.SaveChangesAsync(); 
}