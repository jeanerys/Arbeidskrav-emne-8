﻿namespace Todo.Api.Repositories.Implementations;

using Microsoft.EntityFrameworkCore;
using Todo.Api.Data;
using Todo.Api.Models;
using Todo.Api.Repositories.Interfaces;

public class CategoryRepository : ICategoryRepository
{
    private readonly TodoItemContext _context;

    public CategoryRepository(TodoItemContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Category>> GetAllAsync() =>
        await _context.Categories.ToListAsync();

    public async Task<Category?> GetByIdAsync(int id) =>
        await _context.Categories.FirstOrDefaultAsync(c => c.Id == id);

    public async Task AddAsync(Category category) =>
        await _context.Categories.AddAsync(category);

    public Task UpdateAsync(Category category)
    {
        _context.Categories.Update(category);
        return Task.CompletedTask;
    }

    public async Task DeleteAsync(int id)
    {
        var category = await _context.Categories.FindAsync(id);
        if (category != null)
        {
            _context.Categories.Remove(category);
        }
    }

    public async Task SaveChangesAsync() =>
        await _context.SaveChangesAsync();
}