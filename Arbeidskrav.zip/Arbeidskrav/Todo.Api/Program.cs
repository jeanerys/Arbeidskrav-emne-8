using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;
using Serilog;
using Todo.Api.Data;
using Todo.Api.Repositories.Implementations;
using Todo.Api.Repositories.Interfaces;
using Todo.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// Configure the backend API to listen on port 80
builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenAnyIP(80);
});

// Add services to the container.

Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File("logs/log-.txt", rollingInterval: RollingInterval.Day)
    .CreateLogger();

builder.Host.UseSerilog();

builder.Services.AddDbContext<TodoItemContext>(options =>
    options.UseMySql(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        new MySqlServerVersion(new Version(8, 3, 0)),
        options => options.EnableRetryOnFailure(
            maxRetryCount: 10,
            maxRetryDelay: TimeSpan.FromSeconds(30),
            errorNumbersToAdd: null)
    )
);

builder.Services.AddScoped<ITodoRepository, TodoRepository>();
builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();
builder.Services.AddScoped<TodoItemService>();
builder.Services.AddScoped<CategoryService>();

// Add CORS middleware and configure it to allow requests from the nginx proxy
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(builder =>
    {
        builder.WithOrigins("http://localhost")
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.Preserve;
    });


builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "Todo API",
        Version = "v1",
        Description = "A simple Todo API"
    });
});

var app = builder.Build();

// Remove duplicate database initialization and add proper error handling and auto-update
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var logger = services.GetRequiredService<ILogger<Program>>();
    try
    {
        var context = services.GetRequiredService<TodoItemContext>();
        logger.LogInformation("Starting automatic database migration");
        context.Database.Migrate();
        logger.LogInformation("Database migration completed successfully");

        logger.LogInformation("Initializing seed data");
        SeedData.Initialize(context);
        logger.LogInformation("Seed data initialization completed");
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "An error occurred while migrating or seeding the database");
        throw;
    }
}

app.UseExceptionHandler(appError =>
{
    appError.Run(async context =>
    {
        context.Response.StatusCode = StatusCodes.Status500InternalServerError;
        context.Response.ContentType = "application/json";

        var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
        if (contextFeature != null)
        {
            Log.Error(contextFeature.Error, "Uventet feil oppstod.");
            await context.Response.WriteAsJsonAsync(new
            {
                StatusCode = context.Response.StatusCode,
                Message = "En feil oppstod på serveren. Vennligst prøv igjen senere."
            });
        }
    });
});

app.Use(async (context, next) =>
{
    Log.Information("HTTP {Method} {Path} initiert", context.Request.Method, context.Request.Path);
    await next.Invoke();
    Log.Information("HTTP {Method} {Path} svarte {StatusCode}", context.Request.Method, context.Request.Path, context.Response.StatusCode);
});

// Comment out HTTPS redirection
//app.UseHttpsRedirection();

app.UseAuthorization();

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Todo API V1");
    c.RoutePrefix = "swagger";
});

// Use CORS middleware
app.UseCors();

app.MapControllers();

app.Run();