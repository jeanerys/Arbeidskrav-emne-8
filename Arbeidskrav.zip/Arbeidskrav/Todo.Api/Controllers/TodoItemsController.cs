﻿using Microsoft.AspNetCore.Mvc;
using Serilog;
using Todo.Api.Models;
using Todo.Api.Services;

namespace Todo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TodoItemsController : ControllerBase
    {
        private readonly TodoItemService _todoService;

        public TodoItemsController(TodoItemService todoService)
        {
            _todoService = todoService;
        }

        [HttpGet] // GET /api/Todos
        public async Task<ActionResult<IEnumerable<TodoItem>>> GetTodos()
        {
            try
            {
                var todos = await _todoService.GetTodosAsync();
                return Ok(todos);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Feil under henting av Todos");
                return StatusCode(500, new { message = "En feil oppstod på serveren. Vennligst prøv igjen senere." });
            }
        }

        [HttpGet("{id}")] // GET /api/Todos/{id}
        public async Task<ActionResult<TodoItem>> GetTodoById(int id)
        {
            try
            {
                var todo = await _todoService.GetTodoByIdAsync(id);
                if (todo == null)
                {
                    return NotFound(new { message = "Todo ikke funnet." });
                }
                return Ok(todo);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Feil under henting av Todo med ID {Id}", id);
                return StatusCode(500, new { message = "En feil oppstod på serveren. Vennligst prøv igjen senere." });
            }
        }

        [HttpPost] // POST /api/Todos
        public async Task<ActionResult<TodoItem>> CreateTodo([FromBody] TodoItem newTodo)
        {
            if (string.IsNullOrWhiteSpace(newTodo.Title))
            {
                return BadRequest("Tittel er påkrevd.");
            }

            if (newTodo.IsCompleted)
            {
                return BadRequest("IsCompleted kan ikke settes til true ved oppretting.");
            }

            try
            {
                var createdTodo = await _todoService.CreateTodoAsync(newTodo);
                return CreatedAtAction(nameof(GetTodoById), new { id = createdTodo.Id }, createdTodo);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Feil under oppretting av Todo");
                return StatusCode(500, new { message = "En feil oppstod på serveren. Vennligst prøv igjen senere." });
            }
        }

        [HttpPut("{id}")] // PUT /api/Todos/{id
        public async Task<ActionResult> UpdateTodo(int id, [FromBody] TodoItem updatedTodo)
        {
            try
            {
                var updated = await _todoService.UpdateTodoAsync(id, updatedTodo);
                if (!updated)
                {
                    return NotFound(new { message = "Todo ikke funnet." });
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Feil under oppdatering av Todo med ID {Id}", id);
                return StatusCode(500, new { message = "En feil oppstod på serveren. Vennligst prøv igjen senere." });
            }
        }

        [HttpDelete("{id}")] // DELETE /api/Todos/{id}
        public async Task<ActionResult> DeleteTodo(int id)
        {
            try
            {
                var deleted = await _todoService.DeleteTodoAsync(id);
                if (!deleted)
                {
                    return NotFound(new { message = "Todo ikke funnet." });
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Feil under sletting av Todo med ID {Id}", id);
                return StatusCode(500, new { message = "En feil oppstod på serveren. Vennligst prøv igjen senere." });
            }
        }

        [HttpGet("category/{categoryId}")] // GET /api/Todos/category/{categoryId}
        public async Task<ActionResult<IEnumerable<TodoItem>>> GetTodosByCategory(int categoryId)
        {
            try
            {
                var todos = await _todoService.GetTodosByCategoryAsync(categoryId);
                return Ok(todos);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Feil under henting av Todos for kategori med ID {CategoryId}", categoryId);
                return StatusCode(500, new { message = "En feil oppstod på serveren. Vennligst prøv igjen senere." });
            }
        }

        [HttpGet("category/{categoryId}/count")] // GET /api/Todos/category/{categoryId}/count
        public async Task<ActionResult<int>> GetTodoCountByCategory(int categoryId)
        {
            try
            {
                var count = await _todoService.GetTodoCountByCategoryAsync(categoryId);
                return Ok(count);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Feil under telling av oppgaver for kategori {CategoryId}", categoryId);
                return StatusCode(500, new { message = "En feil oppstod på serveren." });
            }
        }

        [HttpGet("completed")] // GET /api/Todos/completed
        public async Task<ActionResult<IEnumerable<TodoItem>>> GetCompletedTodos()
        {
            try
            {
                var todos = await _todoService.GetCompletedTodosWithCategoryAsync();
                return Ok(todos);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Feil under henting av fullførte oppgaver");
                return StatusCode(500, new { message = "En feil oppstod på serveren." });
            }
        }
    }
}