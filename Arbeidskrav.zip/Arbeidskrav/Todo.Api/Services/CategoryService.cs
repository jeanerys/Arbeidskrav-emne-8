﻿using Todo.Api.Models;
using Todo.Api.Repositories.Interfaces;

public class CategoryService
{
    private readonly ICategoryRepository _repository; //2

    public CategoryService(ICategoryRepository repository)
    {
        _repository = repository;
    }

    public async Task<IEnumerable<Category>> GetCategoriesAsync() =>
        await _repository.GetAllAsync();

    public async Task<Category?> GetCategoryByIdAsync(int id) =>
        await _repository.GetByIdAsync(id);

    public async Task<Category> CreateCategoryAsync(Category newCategory)
    {
        await _repository.AddAsync(newCategory);
        await _repository.SaveChangesAsync();
        return newCategory;
    }

    public async Task<bool> UpdateCategoryAsync(int id, Category updatedCategory)
    {
        var existingCategory = await _repository.GetByIdAsync(id);
        if (existingCategory == null) return false;

        existingCategory.Name = updatedCategory.Name;
        await _repository.UpdateAsync(existingCategory);
        await _repository.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteCategoryAsync(int id)
    {
        var category = await _repository.GetByIdAsync(id);
        if (category == null) return false;

        await _repository.DeleteAsync(id);
        await _repository.SaveChangesAsync();
        return true;
    }
}