﻿using Serilog;
using Todo.Api.Models;
using Todo.Api.Repositories.Interfaces;

namespace Todo.Api.Services
{
    public class TodoItemService
    {
        private readonly ITodoRepository _repository;

        public TodoItemService(ITodoRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<TodoItem>> GetTodosAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<TodoItem?> GetTodoByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task<TodoItem> CreateTodoAsync(TodoItem newTodo)
        {
            await _repository.AddAsync(newTodo);
            await _repository.SaveChangesAsync();
            return newTodo;
        }

        public async Task<bool> UpdateTodoAsync(int id, TodoItem updatedTodo)
        {
            var existingTodo = await _repository.GetByIdAsync(id);
            if (existingTodo == null) return false;

            existingTodo.Title = updatedTodo.Title;
            existingTodo.Description = updatedTodo.Description;
            existingTodo.IsCompleted = updatedTodo.IsCompleted;
            existingTodo.CategoryId = updatedTodo.CategoryId;

            await _repository.UpdateAsync(existingTodo);
            await _repository.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteTodoAsync(int id)
        {
            var existingTodo = await _repository.GetByIdAsync(id);
            if (existingTodo == null) return false;

            await _repository.DeleteAsync(id);
            await _repository.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<TodoItem>> GetTodosByCategoryAsync(int categoryId)
        {
            var todos = await _repository.GetAllAsync();
            return todos.Where(todo => todo.CategoryId == categoryId);
        }

        public async Task<int> GetTodoCountByCategoryAsync(int categoryId)
        {
            var todos = await _repository.GetAllAsync();
            return todos.Count(todo => todo.CategoryId == categoryId);
        }

        public async Task<IEnumerable<TodoItem>> GetCompletedTodosWithCategoryAsync()
        {
            var todos = await _repository.GetAllAsync();
            return todos.Where(todo => todo.IsCompleted);
        }
    }
}