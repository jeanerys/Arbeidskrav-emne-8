﻿
using Todo.Api.Models;

namespace Todo.Api.Data
{
    public static class SeedData
    {
        public static void Initialize(TodoItemContext context)
        {
            if (!context.Categories.Any() && !context.TodoItems.Any())
            {
                var categories = new[]
                {
                    new Category { Name = "Arbeid" },
                    new Category { Name = "Personlig" },
                    new Category { Name = "Shopping" }
                };
                context.Categories.AddRange(categories);
                context.SaveChanges();

                context.TodoItems.AddRange(
                    new TodoItem { Title = "Julehandel", Description = "Kjøp pepperkaker, julebrus og svineribbe til julaften.", Category = categories[2] },
                    new TodoItem { Title = "Skoleoppgave", Description = "Lever inn arbeidskravet før fristen går ut.", Category = categories[0] },
                    new TodoItem { Title = "Nyttårsfortsett", Description = "Lag en liste med nyttårsfortsett for 2025.", Category = categories[1] }
                );
                context.SaveChanges();
            }
        }
    }
}