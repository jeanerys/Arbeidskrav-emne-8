﻿using Microsoft.EntityFrameworkCore;
using Todo.Api.Models;

namespace Todo.Api.Data;

public class TodoItemContext : DbContext
{
    public TodoItemContext(DbContextOptions<TodoItemContext> options) : base(options) { }

    public DbSet<TodoItem> TodoItems { get; set; }
    public DbSet<Category> Categories { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TodoItem>()
            .Property(t => t.IsCompleted)
            .HasDefaultValue(false);

        modelBuilder.Entity<TodoItem>()
            .HasOne(t => t.Category)
            .WithMany(c => c.Todos)
            .HasForeignKey(t => t.CategoryId)
            .OnDelete(DeleteBehavior.Cascade);

        // Legg til auto-increment for MySQL
        modelBuilder.Entity<TodoItem>()
            .Property(t => t.Id)
            .ValueGeneratedOnAdd()
            .UseMySqlIdentityColumn();

        modelBuilder.Entity<Category>()
            .Property(c => c.Id)
            .ValueGeneratedOnAdd()
            .UseMySqlIdentityColumn();
    }
}