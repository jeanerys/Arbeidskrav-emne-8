﻿using Microsoft.AspNetCore.Http;
using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Todo.Api.Models;
using System.Text.Json;
using System.ComponentModel.DataAnnotations;
using Todo.Api.Exceptions;

namespace Todo.Api.Middleware
{
    public class GlobalExceptionHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<GlobalExceptionHandlerMiddleware> _logger;

        public GlobalExceptionHandlerMiddleware(RequestDelegate next, ILogger<GlobalExceptionHandlerMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (ValidationException ex)
            {
                _logger.LogError(ex, "Valideringsfeil");
                httpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                await WriteResponseAsync(httpContext, new { message = "Valideringsfeil", details = ex.Message });
            }
            catch (NotFoundException ex)
            {
                _logger.LogError(ex, "Ikke funnet");
                httpContext.Response.StatusCode = (int)HttpStatusCode.NotFound;
                await WriteResponseAsync(httpContext, new { message = "Ikke funnet", details = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Uventet feil");
                httpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                await WriteResponseAsync(httpContext, new { message = "Uventet feil", details = ex.Message });
            }
        }

        private static async Task WriteResponseAsync(HttpContext context, object response)
        {
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsync(JsonSerializer.Serialize(response));
        }
    }
}