﻿using Microsoft.AspNetCore.Http;
using System.IO;
using System.Threading.Tasks;

namespace Todo.Api.Middleware
{
    public class LoggingMiddleware
    {
        private readonly RequestDelegate _next;

        public LoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            var method = httpContext.Request.Method;
            var path = httpContext.Request.Path;
            var requestBody = await new StreamReader(httpContext.Request.Body).ReadToEndAsync();

            System.Console.WriteLine($"Request: {method} {path} - Body: {requestBody}");

            await _next(httpContext);

            var statusCode = httpContext.Response.StatusCode;
            System.Console.WriteLine($"Response: {statusCode}");
        }
    }
}